# CCHAGA Agriculture Information & Management Portal

A Flask + SQLite demonstration website for the Centre for Climate-Smart, Hydroponic, Aeroponic and Geoponic Agriculture (CCHAGA), Federal Polytechnic Damaturu.

## Features

### Public website
- CCHAGA-branded homepage using the supplied proposed logo
- Knowledge hub with article categories and article detail pages
- Systems & Facilities catalogue
- About and contact pages
- Responsive desktop/mobile design

### User side
- User registration and login
- Personal dashboard
- Submit enquiries and view enquiry status
- Browse articles and systems/facilities

### Admin side
- Admin dashboard with user, article, facility and enquiry counts
- Create and delete knowledge articles; publish or save as draft
- Create and delete systems/facility catalogue entries
- Review enquiries and update their status (New, In Progress, Resolved)

## Requirements
- Python 3.10 or newer recommended
- Flask 3.x
- Windows, macOS or Linux

## Windows installation
1. Extract the ZIP.
2. Open the extracted `CCHAGA_Agriculture_Portal` folder in VS Code.
3. Open Terminal and run:

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

4. Open `http://127.0.0.1:5000` in your browser.

## Demo accounts
- Admin: `admin@cchaga.local` / `Admin123!`
- User: `user@cchaga.local` / `User123!`

Change these credentials and the Flask secret key before any public deployment. The demo passwords are only for local testing.

## Database
SQLite database is created automatically at `instance/cchaga.db` the first time the app runs.

## Important customisation
This project is an academic starter implementation. Replace sample articles, contact details, policies and facility descriptions with information approved by CCHAGA/Federal Polytechnic Damaturu. The logo supplied was used as requested. This is an original implementation inspired by the broad blog/resource layout and subject matter of the reference website; it does not copy the site's source code, branding or proprietary media.

## Security before deployment
- Set a strong random `SECRET_KEY` environment variable.
- Change/remove demo accounts.
- Disable Flask debug mode.
- Use HTTPS and a production WSGI server.
- Add CSRF protection, rate limiting, email verification and backups before public deployment.
