import os, sqlite3
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE, "instance", "cchaga.db")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key-before-deployment")

def db():
    if "db" not in g:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    with app.app_context():
        con = db()
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'user', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS posts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          category TEXT NOT NULL, summary TEXT NOT NULL, body TEXT NOT NULL,
          published INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          category TEXT NOT NULL, description TEXT NOT NULL,
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS inquiries(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
          name TEXT NOT NULL, email TEXT NOT NULL, phone TEXT,
          subject TEXT NOT NULL, message TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'New', created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id));
        """)
        if not con.execute("SELECT id FROM users WHERE email=?", ("admin@cchaga.local",)).fetchone():
            con.execute("INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)",
                        ("CCHAGA Administrator","admin@cchaga.local",generate_password_hash("Admin123!"),"admin",datetime.now().isoformat(timespec="seconds")))
        if not con.execute("SELECT id FROM users WHERE email=?", ("user@cchaga.local",)).fetchone():
            con.execute("INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)",
                        ("Demo User","user@cchaga.local",generate_password_hash("User123!"),"user",datetime.now().isoformat(timespec="seconds")))
        if con.execute("SELECT COUNT(*) FROM posts").fetchone()[0] == 0:
            sample_posts = [
              ("Greenhouse accessories and their importance","Greenhouse Knowledge","A practical overview of structural components that support safe greenhouse operation.",
               "Greenhouse accessories contribute to the stability, ventilation and efficient operation of protected cultivation facilities. Components such as braces, fasteners, screens, irrigation lines and film rollers should be selected and maintained according to the greenhouse design. Inspect structural connections regularly and replace damaged components promptly."),
              ("Understanding hydroponic production","Hydroponics","An introduction to growing plants with nutrient-rich water instead of field soil.",
               "Hydroponics is a soilless production method in which plant roots receive water and dissolved nutrients. Successful operation requires attention to water quality, nutrient concentration, pH, sanitation and crop requirements. A well-managed system can support efficient water use, but it still requires monitoring and technical knowledge."),
              ("Aeroponics and controlled root environments","Aeroponics","How mist-based root systems can support controlled-environment crop production.",
               "Aeroponics suspends plant roots in an air chamber and supplies moisture and nutrients as a fine mist. System reliability is important because roots can dry quickly if misting stops. Filtration, pump maintenance, backup power and regular inspection are essential considerations."),
              ("Geoponic cultivation in protected structures","Geoponics","Using soil-based growing beds within protected agricultural environments.",
               "Geoponic cultivation uses soil as the plant-growing medium. In a greenhouse, soil preparation, drainage, organic matter, salinity management and crop rotation remain important. Protected structures can help manage some environmental stresses but do not remove the need for good soil management.")
            ]
            for p in sample_posts:
                con.execute("INSERT INTO posts(title,category,summary,body,published,created_at) VALUES(?,?,?,?,1,?)", (*p,datetime.now().isoformat(timespec="seconds")))
        if con.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
            sample_products = [
              ("Protected Greenhouse Structures","Greenhouse Systems","Planning information for glass, multi-span film and naturally ventilated greenhouse structures."),
              ("Hydroponic Growing Channels","Hydroponics","Growing channels and troughs for recirculating nutrient-solution cultivation."),
              ("Aeroponic Mist System","Aeroponics","A demonstration category for pumps, mist nozzles, filters and root chambers."),
              ("Irrigation and Fertigation Kit","Irrigation","Equipment category for controlled irrigation, nutrient dosing and water distribution."),
              ("Seedling and Nursery Equipment","Nursery","Seedling trays, benches and nursery support equipment for propagation.")
            ]
            for p in sample_products:
                con.execute("INSERT INTO products(name,category,description,created_at) VALUES(?,?,?,?)", (*p,datetime.now().isoformat(timespec="seconds")))
        con.commit()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            abort(403)
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def inject_user():
    return {"current_user": session.get("name"), "current_role": session.get("role")}

@app.route("/")
def home():
    posts = db().execute("SELECT * FROM posts WHERE published=1 ORDER BY id DESC LIMIT 3").fetchall()
    products = db().execute("SELECT * FROM products ORDER BY id LIMIT 4").fetchall()
    return render_template("home.html", posts=posts, products=products)

@app.route("/articles")
def articles():
    category = request.args.get("category","").strip()
    if category:
        posts = db().execute("SELECT * FROM posts WHERE published=1 AND category=? ORDER BY id DESC",(category,)).fetchall()
    else:
        posts = db().execute("SELECT * FROM posts WHERE published=1 ORDER BY id DESC").fetchall()
    categories = db().execute("SELECT DISTINCT category FROM posts WHERE published=1 ORDER BY category").fetchall()
    return render_template("articles.html", posts=posts, categories=categories, selected=category)

@app.route("/article/<int:post_id>")
def article(post_id):
    post = db().execute("SELECT * FROM posts WHERE id=? AND published=1",(post_id,)).fetchone()
    if not post: abort(404)
    return render_template("article.html", post=post)

@app.route("/products")
def products():
    items = db().execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    return render_template("products.html", products=items)

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact", methods=["GET","POST"])
def contact():
    if request.method == "POST":
        name=request.form.get("name","").strip()
        email=request.form.get("email","").strip()
        phone=request.form.get("phone","").strip()
        subject=request.form.get("subject","").strip()
        message=request.form.get("message","").strip()
        if not all([name,email,subject,message]):
            flash("Please complete all required fields.","danger")
        else:
            db().execute("INSERT INTO inquiries(user_id,name,email,phone,subject,message,created_at) VALUES(?,?,?,?,?,?,?)",
                         (session.get("user_id"),name,email,phone,subject,message,datetime.now().isoformat(timespec="seconds")))
            db().commit()
            flash("Your message has been submitted successfully.","success")
            return redirect(url_for("contact"))
    return render_template("contact.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name=request.form.get("name","").strip()
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        if not name or not email or len(password)<6:
            flash("Enter your name, a valid email and a password of at least 6 characters.","danger")
        else:
            try:
                db().execute("INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)",
                             (name,email,generate_password_hash(password),"user",datetime.now().isoformat(timespec="seconds")))
                db().commit()
                flash("Registration successful. You can now log in.","success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That email address is already registered.","danger")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        user=db().execute("SELECT * FROM users WHERE email=?",(email,)).fetchone()
        if user and check_password_hash(user["password"],password):
            session.clear()
            session.update(user_id=user["id"],name=user["name"],role=user["role"],email=user["email"])
            flash("Welcome back, "+user["name"]+".","success")
            return redirect(url_for("admin_dashboard" if user["role"]=="admin" else "user_dashboard"))
        flash("Invalid email or password.","danger")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.","info")
    return redirect(url_for("home"))

@app.route("/dashboard")
@login_required
def user_dashboard():
    if session.get("role")=="admin": return redirect(url_for("admin_dashboard"))
    con=db()
    inquiries=con.execute("SELECT * FROM inquiries WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    return render_template("user_dashboard.html", inquiries=inquiries)

@app.route("/admin")
@login_required
@admin_required
def admin_dashboard():
    con=db()
    stats={
      "users":con.execute("SELECT COUNT(*) FROM users WHERE role='user'").fetchone()[0],
      "posts":con.execute("SELECT COUNT(*) FROM posts").fetchone()[0],
      "products":con.execute("SELECT COUNT(*) FROM products").fetchone()[0],
      "inquiries":con.execute("SELECT COUNT(*) FROM inquiries").fetchone()[0],
      "new":con.execute("SELECT COUNT(*) FROM inquiries WHERE status='New'").fetchone()[0]
    }
    recent=con.execute("SELECT * FROM inquiries ORDER BY id DESC LIMIT 6").fetchall()
    return render_template("admin.html",stats=stats,recent=recent)

@app.route("/admin/posts", methods=["GET","POST"])
@login_required
@admin_required
def admin_posts():
    con=db()
    if request.method=="POST":
        title=request.form.get("title","").strip(); category=request.form.get("category","").strip()
        summary=request.form.get("summary","").strip(); body=request.form.get("body","").strip()
        published=1 if request.form.get("published")=="on" else 0
        if all([title,category,summary,body]):
            con.execute("INSERT INTO posts(title,category,summary,body,published,created_at) VALUES(?,?,?,?,?,?)",
                        (title,category,summary,body,published,datetime.now().isoformat(timespec="seconds")))
            con.commit(); flash("Article saved.","success")
        else: flash("Complete all article fields.","danger")
        return redirect(url_for("admin_posts"))
    posts=con.execute("SELECT * FROM posts ORDER BY id DESC").fetchall()
    return render_template("manage_posts.html",posts=posts)

@app.route("/admin/posts/delete/<int:post_id>", methods=["POST"])
@login_required
@admin_required
def delete_post(post_id):
    db().execute("DELETE FROM posts WHERE id=?",(post_id,)); db().commit()
    flash("Article deleted.","success"); return redirect(url_for("admin_posts"))

@app.route("/admin/products", methods=["GET","POST"])
@login_required
@admin_required
def admin_products():
    con=db()
    if request.method=="POST":
        name=request.form.get("name","").strip(); category=request.form.get("category","").strip(); description=request.form.get("description","").strip()
        if all([name,category,description]):
            con.execute("INSERT INTO products(name,category,description,created_at) VALUES(?,?,?,?)",(name,category,description,datetime.now().isoformat(timespec="seconds")))
            con.commit(); flash("Product category saved.","success")
        else: flash("Complete all product fields.","danger")
        return redirect(url_for("admin_products"))
    items=con.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    return render_template("manage_products.html",products=items)

@app.route("/admin/products/delete/<int:item_id>", methods=["POST"])
@login_required
@admin_required
def delete_product(item_id):
    db().execute("DELETE FROM products WHERE id=?",(item_id,)); db().commit()
    flash("Item deleted.","success"); return redirect(url_for("admin_products"))

@app.route("/admin/inquiries")
@login_required
@admin_required
def admin_inquiries():
    rows=db().execute("SELECT * FROM inquiries ORDER BY id DESC").fetchall()
    return render_template("inquiries.html",inquiries=rows)

@app.route("/admin/inquiries/<int:item_id>/status", methods=["POST"])
@login_required
@admin_required
def update_inquiry(item_id):
    status=request.form.get("status","New")
    if status not in ("New","In Progress","Resolved"): status="New"
    db().execute("UPDATE inquiries SET status=? WHERE id=?",(status,item_id)); db().commit()
    flash("Inquiry status updated.","success")
    return redirect(url_for("admin_inquiries"))

@app.errorhandler(403)
def forbidden(e): return render_template("message.html",title="Access denied",message="You do not have permission to view this page."),403
@app.errorhandler(404)
def not_found(e): return render_template("message.html",title="Page not found",message="The page you requested could not be found."),404

init_db()
if __name__ == "__main__":
    app.run(debug=True)
